---
title: A minimal landing page for developers
description: A minimal landing page for developers.
date: 2018-04-06
url: https://github.com/flexdinesh/dev-landing-page
---
