---
external: false
draft: true
title: Draft Post
description: This post is a draft and won't be built.
date: 2022-11-22
---

It's a beautiful world out there.
