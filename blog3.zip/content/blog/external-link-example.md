---
external: true
url: https://medium.com/the-thinkmill/progressive-rendering-the-key-to-faster-web-ebfbbece41a4
title: You can also link to an external blog post
description: Safely access nested objects in JavaScript in a super cool way.
date: 2019-11-11
---
